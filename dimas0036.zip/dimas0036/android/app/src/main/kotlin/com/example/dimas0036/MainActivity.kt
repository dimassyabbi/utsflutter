package com.example.dimas0036

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
